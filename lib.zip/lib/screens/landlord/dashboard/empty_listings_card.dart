import 'package:flutter/material.dart';
import '../../../utils/theme.dart';

class EmptyListingsCard extends StatelessWidget {
  const EmptyListingsCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: const Center(
        child: Column(
          children: [
            Icon(Icons.home_work_outlined, size: 48, color: AppTheme.gray),
            SizedBox(height: 12),
            Text(
              'No listings yet',
              style: TextStyle(
                color: AppTheme.gray,
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 4),
            Text(
              'Tap Add New to create your first listing',
              style: TextStyle(color: AppTheme.gray, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
