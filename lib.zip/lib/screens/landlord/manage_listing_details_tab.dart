part of 'manage_listing_screen.dart';

class _DetailsTab extends StatefulWidget {
  final Property property;
  final VoidCallback onUpdated;

  const _DetailsTab({required this.property, required this.onUpdated});

  @override
  State<_DetailsTab> createState() => _DetailsTabState();
}

class _DetailsTabState extends State<_DetailsTab> {
  final ApiService _api = ApiService();
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;
  late TextEditingController _addressController;
  late bool _hasWifi;
  late bool _hasWater;
  late bool _hasElectricity;
  late bool _hasSecurity;
  bool _isLoading = false;
  bool _hasChanges = false;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.property.title);
    _descriptionController = TextEditingController(
      text: widget.property.description ?? '',
    );
    _addressController = TextEditingController(text: widget.property.address);
    _hasWifi = widget.property.amenities['wifi'] == true;
    _hasWater = widget.property.amenities['water'] == true;
    _hasElectricity = widget.property.amenities['electricity'] == true;
    _hasSecurity = widget.property.amenities['security'] == true;
  }

  Future<void> _saveChanges() async {
    setState(() => _isLoading = true);
    try {
      await _api.updateProperty(widget.property.id, {
        'title': _titleController.text.trim(),
        'description': _descriptionController.text.trim(),
        'address': _addressController.text.trim(),
        'amenities': {
          'wifi': _hasWifi,
          'water': _hasWater,
          'electricity': _hasElectricity,
          'security': _hasSecurity,
        },
      });
      setState(() {
        _isLoading = false;
        _hasChanges = false;
      });
      widget.onUpdated();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Changes saved successfully')),
        );
      }
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: Row(
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    color:
                        widget.property.isApproved
                            ? AppTheme.success
                            : AppTheme.warning,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  widget.property.isApproved
                      ? 'Live — visible to students'
                      : 'Pending admin approval',
                  style: TextStyle(
                    fontSize: 13,
                    color:
                        widget.property.isApproved
                            ? AppTheme.success
                            : AppTheme.warning,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const Spacer(),
                Text(
                  '${widget.property.viewCount} views',
                  style: const TextStyle(fontSize: 12, color: AppTheme.gray),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _fieldLabel('Title'),
          const SizedBox(height: 6),
          TextField(
            controller: _titleController,
            onChanged: (_) => setState(() => _hasChanges = true),
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.home_work_outlined),
            ),
          ),
          const SizedBox(height: 16),
          _fieldLabel('Address'),
          const SizedBox(height: 6),
          TextField(
            controller: _addressController,
            onChanged: (_) => setState(() => _hasChanges = true),
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.location_on_outlined),
            ),
          ),
          const SizedBox(height: 16),
          _fieldLabel('Description'),
          const SizedBox(height: 6),
          TextField(
            controller: _descriptionController,
            maxLines: 4,
            onChanged: (_) => setState(() => _hasChanges = true),
            decoration: const InputDecoration(
              hintText: 'Describe your property...',
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 20),
          _fieldLabel('Amenities'),
          const SizedBox(height: 10),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: Column(
              children: [
                _amenitySwitch(
                  'WiFi',
                  Icons.wifi,
                  _hasWifi,
                  (v) => setState(() {
                    _hasWifi = v;
                    _hasChanges = true;
                  }),
                ),
                _amenitySwitch(
                  'Water',
                  Icons.water_drop_outlined,
                  _hasWater,
                  (v) => setState(() {
                    _hasWater = v;
                    _hasChanges = true;
                  }),
                ),
                _amenitySwitch(
                  'Electricity',
                  Icons.bolt_outlined,
                  _hasElectricity,
                  (v) => setState(() {
                    _hasElectricity = v;
                    _hasChanges = true;
                  }),
                ),
                _amenitySwitch(
                  'Security',
                  Icons.security_outlined,
                  _hasSecurity,
                  (v) => setState(() {
                    _hasSecurity = v;
                    _hasChanges = true;
                  }),
                  isLast: true,
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          if (_hasChanges)
            ElevatedButton(
              onPressed: _isLoading ? null : _saveChanges,
              child:
                  _isLoading
                      ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                      : const Text('Save Changes'),
            ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  Widget _fieldLabel(String label) => Text(
    label,
    style: const TextStyle(
      fontSize: 13,
      fontWeight: FontWeight.w500,
      color: AppTheme.dark,
    ),
  );

  Widget _amenitySwitch(
    String label,
    IconData icon,
    bool value,
    ValueChanged<bool> onChanged, {
    bool isLast = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        border:
            isLast
                ? null
                : const Border(bottom: BorderSide(color: Color(0xFFE2E8F0))),
      ),
      child: SwitchListTile(
        value: value,
        onChanged: onChanged,
        activeColor: AppTheme.primary,
        title: Row(
          children: [
            Icon(
              icon,
              size: 18,
              color: value ? AppTheme.primary : AppTheme.gray,
            ),
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                color: value ? AppTheme.dark : AppTheme.gray,
                fontWeight: value ? FontWeight.w500 : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── PHOTOS TAB ────────────────────────────────────────────────

