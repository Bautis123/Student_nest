part of 'manage_listing_screen.dart';

class _RoomsTab extends StatefulWidget {
  final Property property;
  final VoidCallback onUpdated;

  const _RoomsTab({required this.property, required this.onUpdated});

  @override
  State<_RoomsTab> createState() => _RoomsTabState();
}

class _RoomsTabState extends State<_RoomsTab> {
  final ApiService _api = ApiService();

  Future<void> _addRoomDialog() async {
    final priceController = TextEditingController();
    int studentsPerRoom = 1;
    int totalRooms = 1;
    final roomTypes = ['single', 'double', 'shared', 'self-contained'];
    String selectedType = 'single';

    await showDialog(
      context: context,
      builder:
          (_) => StatefulBuilder(
            builder:
                (ctx, setModalState) => AlertDialog(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  title: const Text('Add Room Type'),
                  content: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        DropdownButtonFormField<String>(
                          value: selectedType,
                          decoration: const InputDecoration(
                            labelText: 'Room Type',
                          ),
                          items:
                              roomTypes
                                  .map(
                                    (t) => DropdownMenuItem(
                                      value: t,
                                      child: Text(
                                        t[0].toUpperCase() + t.substring(1),
                                      ),
                                    ),
                                  )
                                  .toList(),
                          onChanged:
                              (v) => setModalState(
                                () => selectedType = v ?? 'single',
                              ),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: priceController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'Price per month (K)',
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Students/room',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: AppTheme.gray,
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      IconButton(
                                        onPressed: () {
                                          if (studentsPerRoom > 1) {
                                            setModalState(
                                              () => studentsPerRoom--,
                                            );
                                          }
                                        },
                                        icon: const Icon(Icons.remove),
                                      ),
                                      Text('$studentsPerRoom'),
                                      IconButton(
                                        onPressed:
                                            () => setModalState(
                                              () => studentsPerRoom++,
                                            ),
                                        icon: const Icon(Icons.add),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Total rooms',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: AppTheme.gray,
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      IconButton(
                                        onPressed: () {
                                          if (totalRooms > 1) {
                                            setModalState(() => totalRooms--);
                                          }
                                        },
                                        icon: const Icon(Icons.remove),
                                      ),
                                      Text('$totalRooms'),
                                      IconButton(
                                        onPressed:
                                            () => setModalState(
                                              () => totalRooms++,
                                            ),
                                        icon: const Icon(Icons.add),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text('Cancel'),
                    ),
                    ElevatedButton(
                      onPressed: () async {
                        if (priceController.text.isEmpty) return;
                        Navigator.pop(ctx);
                        await _api.addRooms(widget.property.id, [
                          {
                            'room_type': selectedType,
                            'price_per_month': double.parse(
                              priceController.text,
                            ),
                            'students_per_room': studentsPerRoom,
                            'total_rooms': totalRooms,
                            'available_rooms': totalRooms,
                          },
                        ]);
                        widget.onUpdated();
                      },
                      child: const Text('Add'),
                    ),
                  ],
                ),
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final rooms = widget.property.rooms;

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ElevatedButton.icon(
            onPressed: _addRoomDialog,
            icon: const Icon(Icons.add),
            label: const Text('Add Room Type'),
          ),
          const SizedBox(height: 16),
          if (rooms.isEmpty)
            Container(
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              child: const Center(
                child: Column(
                  children: [
                    Icon(Icons.bed_outlined, size: 48, color: AppTheme.gray),
                    SizedBox(height: 12),
                    Text(
                      'No room types yet',
                      style: TextStyle(
                        color: AppTheme.gray,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            )
          else
            ...rooms.map(
              (room) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFFE2E8F0)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: AppTheme.primaryLight,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(
                            Icons.bed_outlined,
                            color: AppTheme.primary,
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                room.roomType[0].toUpperCase() +
                                    room.roomType.substring(1),
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                ),
                              ),
                              Text(
                                '${room.studentsPerRoom} student${room.studentsPerRoom > 1 ? 's' : ''}/room · K${room.pricePerMonth.toStringAsFixed(0)}/mo',
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: AppTheme.gray,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    const Divider(height: 1, color: Color(0xFFE2E8F0)),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Available rooms',
                          style: TextStyle(fontSize: 13, color: AppTheme.gray),
                        ),
                        Row(
                          children: [
                            GestureDetector(
                              onTap: () async {
                                if (room.availableRooms > 0) {
                                  await _api.updateRoomAvailability(
                                    room.id,
                                    room.availableRooms - 1,
                                  );
                                  widget.onUpdated();
                                }
                              },
                              child: Container(
                                width: 30,
                                height: 30,
                                decoration: BoxDecoration(
                                  color: AppTheme.primaryLight,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Icon(
                                  Icons.remove,
                                  size: 16,
                                  color: AppTheme.primary,
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Text(
                              '${room.availableRooms}/${room.totalRooms}',
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: AppTheme.dark,
                              ),
                            ),
                            const SizedBox(width: 12),
                            GestureDetector(
                              onTap: () async {
                                if (room.availableRooms < room.totalRooms) {
                                  await _api.updateRoomAvailability(
                                    room.id,
                                    room.availableRooms + 1,
                                  );
                                  widget.onUpdated();
                                }
                              },
                              child: Container(
                                width: 30,
                                height: 30,
                                decoration: BoxDecoration(
                                  color: AppTheme.primaryLight,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Icon(
                                  Icons.add,
                                  size: 16,
                                  color: AppTheme.primary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value:
                            room.totalRooms > 0
                                ? room.availableRooms / room.totalRooms
                                : 0,
                        backgroundColor: const Color(0xFFE2E8F0),
                        valueColor: AlwaysStoppedAnimation<Color>(
                          room.availableRooms == 0
                              ? AppTheme.error
                              : room.availableRooms < room.totalRooms
                              ? AppTheme.warning
                              : AppTheme.success,
                        ),
                        minHeight: 6,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      room.availableRooms == 0
                          ? 'Full — no rooms available'
                          : room.availableRooms == room.totalRooms
                          ? 'All rooms available'
                          : '${room.totalRooms - room.availableRooms} room${room.totalRooms - room.availableRooms > 1 ? 's' : ''} occupied',
                      style: TextStyle(
                        fontSize: 11,
                        color:
                            room.availableRooms == 0
                                ? AppTheme.error
                                : room.availableRooms == room.totalRooms
                                ? AppTheme.success
                                : AppTheme.warning,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
