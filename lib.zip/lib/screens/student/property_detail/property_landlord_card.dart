import 'package:flutter/material.dart';
import '../../../models/property.dart';
import '../../../utils/theme.dart';

class PropertyLandlordCard extends StatelessWidget {
  final Property property;

  const PropertyLandlordCard({super.key, required this.property});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppTheme.primaryLight,
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Icon(Icons.person_outline, color: AppTheme.primary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  property.landlordName ?? 'Landlord',
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                ),
                Text(
                  property.landlordPhone ?? '',
                  style: const TextStyle(color: AppTheme.gray, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
