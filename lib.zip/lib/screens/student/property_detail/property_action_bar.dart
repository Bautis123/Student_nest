import 'package:flutter/material.dart';

class PropertyActionBar extends StatelessWidget {
  final VoidCallback onViewMap;
  final VoidCallback onCall;
  final String landlordName;

  const PropertyActionBar({
    super.key,
    required this.onViewMap,
    required this.onCall,
    required this.landlordName,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Color(0xFFE2E8F0))),
      ),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: onViewMap,
              icon: const Icon(Icons.map_outlined),
              label: const Text('View in Map'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: onCall,
              icon: const Icon(Icons.phone_outlined),
              label: Text('Call $landlordName'),
            ),
          ),
        ],
      ),
    );
  }
}
