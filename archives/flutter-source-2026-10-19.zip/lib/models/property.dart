import 'dart:math' as math;

import 'package:student_nest/core/constants/app_constants.dart';

class Property {
  final String id;
  final String landlordId;
  final String title;
  final String? description;
  final String address;
  final double latitude;
  final double longitude;
  final String? nearestSchoolId;
  final double? distanceFromSchool;
  final Map<String, dynamic> amenities;
  final bool isActive;
  final bool isApproved;
  final int viewCount;
  final int contactClickCount;
  final String? listingExpiresAt;
  final String createdAt;
  final String? schoolName;
  final double? schoolLat;
  final double? schoolLng;
  final String? landlordName;
  final String? landlordPhone;
  final List<Room> rooms;
  final List<Photo> photos;
  final double? minPrice;
  final double? maxPrice;
  final String? listingPlan;
  final bool? isPremiumFlag;
  final int? totalRoomsCount;
  final int? availableRoomsCount;
  final int? occupiedRoomsCount;
  final int? availableSpacesCount;

  Property({
    required this.id,
    required this.landlordId,
    required this.title,
    this.description,
    required this.address,
    required this.latitude,
    required this.longitude,
    this.nearestSchoolId,
    this.distanceFromSchool,
    required this.amenities,
    required this.isActive,
    required this.isApproved,
    required this.viewCount,
    required this.contactClickCount,
    this.listingExpiresAt,
    required this.createdAt,
    this.schoolName,
    this.schoolLat,
    this.schoolLng,
    this.landlordName,
    this.landlordPhone,
    this.rooms = const [],
    this.photos = const [],
    this.minPrice,
    this.maxPrice,
    this.listingPlan,
    this.isPremiumFlag,
    this.totalRoomsCount,
    this.availableRoomsCount,
    this.occupiedRoomsCount,
    this.availableSpacesCount,
  });

  factory Property.fromJson(Map<String, dynamic> json) {
    final rawPhotos = json['photos'] ?? json['cover_photo'];
    return Property(
      id: json['id'],
      landlordId: json['landlord_id'],
      title: json['title'],
      description: json['description'],
      address: json['address'],
      latitude: double.parse(json['latitude'].toString()),
      longitude: double.parse(json['longitude'].toString()),
      nearestSchoolId: json['nearest_school_id'],
      distanceFromSchool:
          json['distance_from_school'] != null
              ? double.parse(json['distance_from_school'].toString())
              : null,
      amenities: json['amenities'] ?? {},
      isActive: json['is_active'] ?? true,
      isApproved: json['is_approved'] ?? false,
      viewCount: json['view_count'] ?? 0,
      contactClickCount: json['contact_click_count'] ?? 0,
      listingExpiresAt: json['listing_expires_at'],
      createdAt: json['created_at'],
      schoolName: json['school_name'],
      schoolLat:
          json['school_lat'] != null
              ? double.tryParse(json['school_lat'].toString())
              : null,
      schoolLng:
          json['school_lng'] != null
              ? double.tryParse(json['school_lng'].toString())
              : null,
      landlordName: json['landlord_name'],
      landlordPhone: json['landlord_phone'],
      rooms:
          json['rooms'] != null
              ? (json['rooms'] as List).map((r) => Room.fromJson(r)).toList()
              : [],
      photos:
          rawPhotos != null
              ? (rawPhotos as List).map((p) => Photo.fromJson(p)).toList()
              : [],
      minPrice:
          json['min_price'] != null
              ? double.parse(json['min_price'].toString())
              : null,
      maxPrice:
          json['max_price'] != null
              ? double.parse(json['max_price'].toString())
              : null,
      listingPlan:
          (json['listing_plan'] ?? json['plan'] ?? json['subscription_plan'])
              ?.toString(),
      isPremiumFlag:
          json['is_premium'] is bool
              ? json['is_premium'] as bool
              : (json['premium'] is bool ? json['premium'] as bool : null),
      totalRoomsCount: _optionalInt(json['total_rooms_count']),
      availableRoomsCount: _optionalInt(json['available_rooms_count']),
      occupiedRoomsCount: _optionalInt(json['occupied_rooms_count']),
      availableSpacesCount: _optionalInt(json['available_spaces_count']),
    );
  }

  static int? _optionalInt(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    return int.tryParse(value.toString());
  }

  bool get isPremium {
    if (isPremiumFlag != null) return isPremiumFlag!;
    final plan = listingPlan?.toLowerCase();
    return plan == 'premium';
  }

  int? get resolvedAvailableSpaces {
    if (availableSpacesCount != null) return availableSpacesCount;
    if (rooms.isNotEmpty) {
      return rooms.fold<int>(
        0,
        (total, room) => total + (room.availableRooms * room.studentsPerRoom),
      );
    }
    return availableRoomsCount;
  }

  bool get isUnzaSchool {
    final normalizedSchool = schoolName?.toLowerCase() ?? '';
    return normalizedSchool.contains('unza') ||
        (normalizedSchool.contains('university') &&
            normalizedSchool.contains('zambia'));
  }

  double? get resolvedSchoolLat {
    if (isUnzaSchool) return AppConstants.defaultLat;
    return schoolLat;
  }

  double? get resolvedSchoolLng {
    if (isUnzaSchool) return AppConstants.defaultLng;
    return schoolLng;
  }

  double? get straightLineDistanceKm {
    if (resolvedSchoolLat != null && resolvedSchoolLng != null) {
      return _distanceInKm(
        latitude,
        longitude,
        resolvedSchoolLat!,
        resolvedSchoolLng!,
      );
    }

    return distanceFromSchool;
  }

  double _distanceInKm(double lat1, double lon1, double lat2, double lon2) {
    const radiusKm = 6371.0;
    final dLat = _toRadians(lat2 - lat1);
    final dLon = _toRadians(lon2 - lon1);
    final a =
        math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(_toRadians(lat1)) *
            math.cos(_toRadians(lat2)) *
            math.sin(dLon / 2) *
            math.sin(dLon / 2);
    final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
    return radiusKm * c;
  }

  double _toRadians(double degree) => degree * math.pi / 180.0;
}

class Room {
  final String id;
  final String propertyId;
  final String roomType;
  final double pricePerMonth;
  final int studentsPerRoom;
  final int totalRooms;
  final int availableRooms;

  Room({
    required this.id,
    required this.propertyId,
    required this.roomType,
    required this.pricePerMonth,
    required this.studentsPerRoom,
    required this.totalRooms,
    required this.availableRooms,
  });

  factory Room.fromJson(Map<String, dynamic> json) {
    return Room(
      id: json['id'],
      propertyId: json['property_id'],
      roomType: json['room_type'] ?? 'single',
      pricePerMonth: double.parse(json['price_per_month'].toString()),
      studentsPerRoom: json['students_per_room'] ?? 1,
      totalRooms: json['total_rooms'] ?? 1,
      availableRooms: json['available_rooms'] ?? 1,
    );
  }
}

class Photo {
  final String id;
  final String propertyId;
  final String url;
  final bool isCover;

  Photo({
    required this.id,
    required this.propertyId,
    required this.url,
    required this.isCover,
  });

  factory Photo.fromJson(Map<String, dynamic> json) {
    return Photo(
      id: json['id'],
      propertyId: json['property_id'],
      url: json['url'],
      isCover: json['is_cover'] ?? false,
    );
  }

  String get cacheAwareUrl {
    final separator = url.contains('?') ? '&' : '?';
    return '$url${separator}sn_photo=$id&cover=${isCover ? 1 : 0}';
  }
}
